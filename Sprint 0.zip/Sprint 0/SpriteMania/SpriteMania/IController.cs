﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

// create interface necessities for IController
public interface IController {

    void Update();
}
