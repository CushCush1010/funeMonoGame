﻿// create interface necessities for ICommand
public interface ICommand
{
	void Execute();
}
