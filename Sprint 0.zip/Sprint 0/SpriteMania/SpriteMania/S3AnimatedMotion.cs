﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using SpriteMania;

public class S3AnimatedMotion : ISprite
{
    // animated stuff
    public Texture2D SpriteAnim { get; set; }
    public int Rows { get; set; }
    public int Columns { get; set; }
    private int currentFrame;
    private int totalFrames;

    // movement stuff
    public Vector2 Position;
    public Vector2 UpdatedPosition;
    public GameTime GameTime;
    private int currentMovement;
    private int totalMovement;
    Game1 Game;

    // class that prepares/transfers all variables for use in other methods
    public S3AnimatedMotion(Texture2D spriteAnim, int rows, int columns, Vector2 position, Game1 game)
    {
        // animation stuff
        SpriteAnim = spriteAnim;
        Rows = rows;
        Columns = columns;
        currentFrame = 0;
        totalFrames = Rows * Columns;

        // movement stuff
        currentMovement = 0;
        totalMovement = 96;
        Position = position;
        Game = game;
        UpdatedPosition = position;
    }

    // mixed both ways of moving texture and animating
    public void Update()
    {
        // added the +1 to make it fully go off screen, since dividing at this big of a number causes remainders
        UpdatedPosition.X += Game.Window.ClientBounds.Width / totalMovement + 1;

        currentFrame++;
        currentMovement++;
        if (currentFrame == totalFrames)
            currentFrame = 0;
        if (currentMovement == totalMovement)
        {
            currentMovement = 0;
            UpdatedPosition = Position;
        }
    }

    // using that animated sprite technique from the notes, changed somethings for style
    public void Draw(SpriteBatch spriteBatch)
    {
        int width = SpriteAnim.Width / Columns;
        int height = SpriteAnim.Height / Rows;
        int row = currentFrame / Columns;
        int column = currentFrame % Columns;

        Rectangle sourceRectangle = new Rectangle(width * column, height * row, width, height);
        Rectangle destinationRectangle = new Rectangle((int)UpdatedPosition.X - ((int)SpriteAnim.Width / 6), (int)UpdatedPosition.Y - ((int)SpriteAnim.Height / 2), width, height);

        spriteBatch.Begin();
        spriteBatch.Draw(SpriteAnim, destinationRectangle, sourceRectangle, Color.White);
        spriteBatch.End();
    }
}
