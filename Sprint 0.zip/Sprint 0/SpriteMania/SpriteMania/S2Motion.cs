﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using SpriteMania;

public class S2Motion : ISprite
{
    public Texture2D Sprite;
    public Vector2 Position;
    public Vector2 UpdatedPosition;
    private int currentMovement;
    private int totalMovement;
    private Texture2D staticTexture;
    private Vector2 vector2;
    private Game1 Game;

    // class that prepares/transfers all variables for use in other methods
    public S2Motion(Texture2D sprite, Vector2 position, Game1 game)
    {
        Sprite = sprite;
        Position = position;
        UpdatedPosition = position;
        Game = game;
        currentMovement = 0;
        totalMovement = 64;
    }

    // added a similar technique shown in the S1Animated.cs but to change movement
    public void Update()
    {
        // added the +1 to make it fully go off screen, since dividing at this big of a number causes remainders
        UpdatedPosition.X += Game.Window.ClientBounds.Width / totalMovement + 1;

        currentMovement++;
        if (currentMovement == totalMovement)
        {
            currentMovement = 0;
            UpdatedPosition = Position;
        }
    }

    // using a normal sprite technique, changed somethings for style
    public void Draw(SpriteBatch spriteBatch)
    {
        Vector2 location = UpdatedPosition;
        spriteBatch.Begin();
        spriteBatch.Draw(Sprite, location, null, Color.White, 0f, new Vector2(Sprite.Width / 2, Sprite.Height / 2), Vector2.One, SpriteEffects.None, 0f);
        spriteBatch.End();
    }
}
