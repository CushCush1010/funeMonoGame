﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System;

public class SText : ISprite
{
    public SpriteFont Font;
    public string Author;
    public string Credits;
    public Vector2 AuthorPosition;
    public Vector2 CreditPosition;

	public SText(SpriteFont font, Vector2 authorPosition, Vector2 creditPosition)
	{
        Font = font;
        AuthorPosition = authorPosition;
        CreditPosition = creditPosition;
	}

    public void Update()
    {
        // can change to whatever for future projects
        Author = "Evan Csuhran";
        Credits = "www.mariouniverse.com/wp-content/img/sprites/arc/mb/mario-luigi-custom.png";
    }

    public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Begin();
        spriteBatch.DrawString(Font, "Author: " + Author, AuthorPosition, Color.Bisque);
        spriteBatch.DrawString(Font, "Credits: " + Credits, CreditPosition, Color.Bisque);
        spriteBatch.End();
    }
}
