﻿
using var game = new SpriteMania.Game1();
game.Run();
