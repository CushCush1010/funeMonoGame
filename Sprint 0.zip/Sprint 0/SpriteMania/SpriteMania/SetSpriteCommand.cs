﻿namespace SpriteMania
{
    // big command repository for the different "SetSprite"s with an execute that changes the current sprite in Game1.cs
    public class SetSpriteCommand : ICommand
    {
        private ISprite sprite;
        private Game1 game;

        public SetSpriteCommand(Game1 game, S0Sprite sprite)
        {
            this.game = game;
            this.sprite = sprite;
        }

        public SetSpriteCommand(Game1 game, S1Animated sprite)
        {
            this.game = game;
            this.sprite = sprite;
        }

        public SetSpriteCommand(Game1 game, S2Motion sprite)
        {
            this.game = game;
            this.sprite = sprite;
        }

        public SetSpriteCommand(Game1 game, S3AnimatedMotion sprite)
        {
            this.game = game;
            this.sprite = sprite;
        }

        public void Execute()
        {
            game.CurrentSprite = sprite;
        }
    }
}