﻿using Microsoft.Xna.Framework.Input;
using SpriteMania;
using System.Collections.Generic;

public class MouseController : IController
{
    // create dictionary for mouse keys
    private Dictionary<string, ICommand> controllerMappings;
    private Game1 Game;

    // constructor, carried the game over into this controller due to the "Quadrant" requirement.
    // it removes the concrete assignment of pixels below in Update()
    public MouseController(Game1 game)
    {
        controllerMappings = new Dictionary<string, ICommand>();
        Game = game;
    }

    // registering command keys
    public void RegisterCommand(string mouse, ICommand command)
    {
        if (!controllerMappings.ContainsKey(mouse))
            controllerMappings.Add(mouse, command);
    }

    public void Update()
    {
        // if a click happens, then find where it happened and execute sprite
        if (Mouse.GetState().LeftButton == ButtonState.Pressed)
        {
            // make code look nice
            int height = Game.Window.ClientBounds.Height;
            int width = Game.Window.ClientBounds.Width;
            int xPos = Mouse.GetState().X;
            int yPos = Mouse.GetState().Y;

            // no motion & no animation - top left
            if (yPos <= height / 2 && xPos <= width / 2)
            {
                // code for sprite position/redirect to S0Sprite.cs
                controllerMappings["TL"].Execute();
            }
            // no motion & animation - top right
            else if (yPos < height / 2 && (width / 2 < xPos && xPos < width))
            {
                // code for sprite position/redirect to S1Animated.cs
                controllerMappings["TR"].Execute();
            }

            // motion & no animation - bottom left
            else if ((height / 2 < yPos && yPos < height) && xPos < width / 2)
            {
                // code for sprite position/redirect to S2Motion.cs
                controllerMappings["BL"].Execute();
            }

            // motion & animation - bottom right
            else if ((height / 2 <= yPos && yPos < height) && (width / 2 <= xPos && xPos < width))
            {
                // code for sprite position/redirect to S3AnimatedMotion.cs
                controllerMappings["BR"].Execute();
            }
        }
        // if right click, exit
        else if (Mouse.GetState().RightButton == ButtonState.Pressed)
        {
            controllerMappings["RC"].Execute();
        }
    }
}
