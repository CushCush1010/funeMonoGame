﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using SpriteMania;

public class S1Animated : ISprite
{
	public Texture2D SpriteAnim { get; set; }
	public int Rows { get; set; }
	public int Columns { get; set; }
	private int currentFrame;
	private int totalFrames;
	Vector2 Position;

    // class that prepares/transfers all variables for use in other methods
    public S1Animated(Texture2D spriteAnim, int rows, int columns, Vector2 position)
	{
		SpriteAnim = spriteAnim;
		Rows = rows;
		Columns = columns;
		currentFrame = 0;
		totalFrames = Rows * Columns;
		Position = position;
    }

	// uses the animation technique from the notes
	public void Update()
	{
		currentFrame++;
		if (currentFrame == totalFrames)
			currentFrame = 0;
	}

    // using that animated sprite technique from the notes, changed somethings for style
    public void Draw(SpriteBatch spriteBatch)
	{
		int width = SpriteAnim.Width / Columns;
		int height = SpriteAnim.Height / Rows;
		int row = currentFrame / Columns;
		int column = currentFrame % Columns;

		Rectangle sourceRectangle = new Rectangle(width  * column, height * row, width, height);
		Rectangle destinationRectangle = new Rectangle((int)Position.X - ((int)SpriteAnim.Width / 6), (int)Position.Y - ((int)SpriteAnim.Height / 2), width, height);

		spriteBatch.Begin();
		spriteBatch.Draw(SpriteAnim, destinationRectangle, sourceRectangle, Color.White);
		spriteBatch.End();
	}
}
