﻿using SpriteMania;

public class ExitCommand : ICommand
{
	// carry our game over to be terminated
	private Game1 game;

	// assign our game
	public ExitCommand(Game1 game)
	{
		this.game = game;
	}

	// exit the game via "ICommand"s interface Execute()
	public void Execute()
	{
		game.Exit();
	}
}
