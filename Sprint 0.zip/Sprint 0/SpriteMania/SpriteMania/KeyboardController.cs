﻿using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;

// almost entirely the one found in the code we were given
public class KeyboardController : IController
{
	// create dictionary for keyboard keys
	private Dictionary<Keys, ICommand> controllerMappings;

	// constructor
	public KeyboardController()
	{
		controllerMappings = new Dictionary<Keys, ICommand>();
	}

	// registering command keys
	public void RegisterCommand(Keys key, ICommand command)
	{
		controllerMappings[key] = command;
	}

	public void Update()
	{
		// have the currently mapped keys perform an action
        Keys[] pressedKeys = Keyboard.GetState().GetPressedKeys();

		foreach (Keys key in pressedKeys)
		{
			if (controllerMappings.ContainsKey(key))
			{
				controllerMappings[key].Execute();
			}
		}
	}
}
