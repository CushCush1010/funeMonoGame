﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;

public class S0Sprite : ISprite
{

    public Texture2D Sprite;
    public Vector2 Position;

    // class that prepares/transfers all variables for use in other methods
    public S0Sprite(Texture2D sprite, Vector2 position)
    {
        Sprite = sprite;
        Position = position;
    }

    public void Update()
	{
        // no need for it
    }

    // using a normal sprite technique, changed somethings for style
    public void Draw(SpriteBatch spriteBatch)
    {
        spriteBatch.Begin();
        spriteBatch.Draw(Sprite, Position, null, Color.White, 0f, new Vector2(Sprite.Width / 2, Sprite.Height / 2), Vector2.One, SpriteEffects.None, 0f);
        spriteBatch.End();
    }

}
