﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;

// Evan Csuhran
// Sprint 0 - 3902
namespace SpriteMania
{
    // the big main C# class, load content is the section that messed me up with classes/interfaces.
    // so it's likely it isn't done exactly as described in the Assignment Document.
    // however, I couldn't find much on how to transfer the load content info/syntax into other classes/interfaces.
    // so, this is my final attempt, which is a bit cluttered.
    public class Game1 : Game
    {
        private GraphicsDeviceManager _graphics;
        private SpriteBatch _spriteBatch;

        // create both sprites for the "game" sprites and "credit" sprites.
        public ISprite CurrentSprite { get; set; }
        public ISprite msg {  get; set; }

        // create controllers and a sprite for "credits"
        private IController keyC;
        private IController mouseC;
        private SpriteFont font;

        public Game1()
        {
            _graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        protected override void Initialize()
        {
            // initialize the controllers
            keyC = new KeyboardController();
            mouseC = new MouseController(this);

            base.Initialize();
        }

        protected override void LoadContent()
        {

            // as said above, I have no idea how you would put this information within the Controller classes.
            // so, this is the final, somewhat, packed solution.
            _spriteBatch = new SpriteBatch(GraphicsDevice);

            // to make it look better/compact in the "concrete class" section below
            int height = this.Window.ClientBounds.Height;
            int width = this.Window.ClientBounds.Width;

            // load textures - static/animated textures and font
            Texture2D staticTexture = Content.Load<Texture2D>("Static-Mario");
            Texture2D animatedTexture = Content.Load<Texture2D>("Animated-Mario");
            font = Content.Load<SpriteFont>("Author");

            // create names for each concrete sprite class
            S0Sprite staticSprite = new S0Sprite(staticTexture, new Vector2(width / 2, height / 2));
            S1Animated animatedSprite = new S1Animated(animatedTexture, 1, 4, new Vector2(width / 2, height / 2));
            S2Motion motionSprite = new S2Motion(staticTexture, new Vector2(0, height / 2), this);
            S3AnimatedMotion animatedMotionSprite = new S3AnimatedMotion(animatedTexture, 1, 4, new Vector2(0, height / 2), this);
            
            // assign a sprite on launchup and link "font"s concrete class
            CurrentSprite = staticSprite;
            msg = new SText(font, new Vector2(10, height - 60), new Vector2(10, height - 30));

            // register the commands (that use each concrete class) for KeyboardController
            ICommand exitCommand = new ExitCommand(this);
            ICommand setStaticSpriteCommand = new SetSpriteCommand(this, staticSprite);
            ICommand setAnimatedSpriteCommand = new SetSpriteCommand(this, animatedSprite);
            ICommand setMovingSpriteCommand = new SetSpriteCommand(this, motionSprite);
            ICommand setMovingAnimatedSpriteCommand = new SetSpriteCommand(this, animatedMotionSprite);

            // register keyboard commands (0, 1, 2, 3, 4)
            (keyC as KeyboardController).RegisterCommand(Keys.D0, exitCommand);
            (keyC as KeyboardController).RegisterCommand(Keys.D1, setStaticSpriteCommand);
            (keyC as KeyboardController).RegisterCommand(Keys.D2, setAnimatedSpriteCommand);
            (keyC as KeyboardController).RegisterCommand(Keys.D3, setMovingSpriteCommand);
            (keyC as KeyboardController).RegisterCommand(Keys.D4, setMovingAnimatedSpriteCommand);

            // register commands for MouseController based on screen quadrants
            (mouseC as MouseController).RegisterCommand("RC", exitCommand);
            (mouseC as MouseController).RegisterCommand("TL", setStaticSpriteCommand);
            (mouseC as MouseController).RegisterCommand("TR", setAnimatedSpriteCommand);
            (mouseC as MouseController).RegisterCommand("BL", setMovingSpriteCommand);
            (mouseC as MouseController).RegisterCommand("BR", setMovingAnimatedSpriteCommand);
        }

        protected override void Update(GameTime gameTime)
        {

            // mouse logic
            mouseC.Update();

            // keyboard logic
            keyC.Update();

            // sprite logic
            CurrentSprite.Update();
            msg.Update();

            base.Update(gameTime);
        }

        protected override void Draw(GameTime gameTime)
        {
            GraphicsDevice.Clear(Color.DodgerBlue);

            // draw both the sprite and text
            CurrentSprite.Draw(_spriteBatch);
            msg.Draw(_spriteBatch);

            base.Draw(gameTime);
        }
    }
}
